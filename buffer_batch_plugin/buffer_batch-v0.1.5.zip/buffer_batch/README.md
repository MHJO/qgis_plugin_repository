# buffer_batch

---

#### QGIS 플러그인

많은 양의 shape 레이어 buffer 처리를 도와주는 플러그인

---
##### latest_version : 0.1.5
* 개발 QGIS 버전 :  3.22.16

##### change log
* 배치모드, 싱글모드



