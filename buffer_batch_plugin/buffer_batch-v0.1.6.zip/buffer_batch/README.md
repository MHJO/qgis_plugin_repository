# gis_my_tool

---

#### QGIS Plugin

* buffer ![image](https://github.com/MHJO/buffer_batch/assets/107253765/ae196def-e22d-41d4-a6f5-d3df256be507)


: 많은 양의 shape 레이어 buffer 처리를 도와주는 도구

* screenshot ![image](https://github.com/MHJO/buffer_batch/assets/107253765/25717d9e-d942-44a2-b7cc-af69790b92af)

: map 영역의 layer를 캡쳐하는 도구

---
* latest_version : 0.1.5
* 개발 QGIS 버전 :  3.22.16

##### change log
* 배치모드
* ![image](https://github.com/MHJO/buffer_batch/assets/107253765/df18868a-fb2e-4221-875d-47e9fa52b7b3)
* 싱글모드
* ![image](https://github.com/MHJO/buffer_batch/assets/107253765/fa5ec6b0-5061-498d-8a0b-1059381d6d10)




